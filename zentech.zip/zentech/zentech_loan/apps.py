from django.apps import AppConfig


class JohnnyTestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'zentech_loan'
