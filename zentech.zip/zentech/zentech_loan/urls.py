from django.urls import path
from . import views

urlpatterns = [
   path('index/', views.the_page)
]